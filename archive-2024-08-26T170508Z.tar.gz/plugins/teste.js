let date = new Date()
console.log(date.getHours())