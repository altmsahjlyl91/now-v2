import fetch from  node-fetch ;

let data;

let buff;

let mimeType;

let fileName;

let apiUrl;

let enviando = false;

const handler = async (m, { command, usedPrefix, conn, text }) => {

  if (!text) throw `*[❗] يجب تقديم اسم الأغنية / الفيديو المطلوب. يرجى كتابة الأمر مع اسم أغنية أو فيديو من YouTube.*\n\n*—◉ مثال 1:*\n *${usedPrefix + command}* ثم قم بكتابه ماتريد تحميلة\n*—◉ مثال 2:*\n *${usedPrefix + command}* https://youtu.be/JLWRZ8eWyZo?si=EmeS9fJvS_OkDk7p`;

       await m.reply("يتم تحميل طلبك الان لحضه من فضلك...⏳");

  if (enviando) return;

  enviando = true;

  try {

    const apiUrls = [

      `https://api-brunosobrino.zipponodes.xyz/api/ytplay?text=${text}`,

      `https://api-brunosobrino.onrender.com/api/ytplay?text=${text}`

    ];

    for (const url of apiUrls) {

      try {

        const res = await fetch(url);

        data = await res.json();

        if (data.resultado && data.resultado.url) {

          break;

        }

      } catch {}

    }

    if (!data.resultado || !data.resultado.url) {

      enviando = false;

      throw `*[❗] لم يتمكن من الحصول على رابط الفيديو / الأغنية.*`;

    } else {

      try {

        if (command ===  play.1  || command ===  صوت   || command ===  اغنية   || command ===  اغنيه ) {

          apiUrl = `https://api-brunosobrino.zipponodes.xyz/api/v1/ytmp3?url=${data.resultado.url}`;

          mimeType =  audio/mpeg ;

          fileName =  error.mp3 ;

          buff = await conn.getFile(apiUrl);

        } else if (command ===  play.2  || command ===  فيديو2 ) {

          apiUrl = `https://api-brunosobrino.zipponodes.xyz/api/v1/ytmp4?url=${data.resultado.url}`;

          mimeType =  video/mp4 ;

          fileName =  error.mp4 ;

          buff = await conn.getFile(apiUrl);

        }

      } catch {

        try {

          if (command ===  play.1  || command ===  صوت ) {

            apiUrl = `https://api-brunosobrino.onrender.com/api/v1/ytmp3?url=${data.resultado.url}`;

            mimeType =  audio/mpeg ;

            fileName =  error.mp3 ;

            buff = await conn.getFile(apiUrl);

          } else if (command ===  play.2  || command ===  فيديو2 ) {

            apiUrl = `https://api-brunosobrino.onrender.com/api/v1/ytmp4?url=${data.resultado.url}`;

            mimeType =  video/mp4 ;

            fileName =  error.mp4 ;

            buff = await conn.getFile(apiUrl);

          }

        } catch {

          enviando = false;

          throw `*[❗] حدث خطأ أثناء تنزيل الفيديو / الأغنية من الواجهات المتاحة.*`;

        }

      }

    }

    const dataMessage = `*◉——⌈🔊 تشغيل يوتيوب 🔊⌋——◉*\n\n❏ 📌 *العنوان:* ${data.resultado.title}\n❏ 📆 *تم النشر:* ${data.resultado.publicDate}\n❏ ⌚ *المدة:* ${data.resultado.duration}\n❏ 👀 *المشاهدات:* ${data.resultado.views}\n❏ 👤 *المؤلف:* ${data.resultado.author}\n❏ ⏯️ *القناة:* ${data.resultado.channel}\n❏ 🆔 *المعرف:* ${data.resultado.id}\n❏ 🪬 *النوع:* ${data.resultado.type}\n❏ 🔗 *الرابط:* ${data.resultado.url}\n\n ❏ *_جاري إرسال المقطع، يرجى الانتظار..._*`;

    await conn.sendMessage(m.chat, { text: dataMessage, background: buff.data, mimetype:  image/jpeg , fileName:  background.jpg  }, { quoted: m });

    if (buff) {

      await conn.sendMessage(m.chat, { [mimeType.startsWith( audio ) ?  audio  :  video ]: buff.data, mimetype: mimeType, fileName: fileName }, { quoted: m });

      enviando = false;

    } else {

      enviando = false;

      throw `*[❗] حدث خطأ أثناء تنزيل الفيديو / الأغنية من الواجهات المتاحة.*`;

    }

  } catch (error) {

    enviando = false;

    throw `*[❗] حدث خطأ: ${error.message ||  حدث خطأ غير متوقع }.*`;

  }

};

handler.help = [ play.1 ,  play.2 ].map((v) => v +   <نص> );

handler.tags = [ downloader ];

handler.command = [ play.1 ,  play.2 ,  صوت ,  فيديو2 , اغنية , اغنيه ];

export default handler;